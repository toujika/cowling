#!/bin/sh
python /home/pi/ascetic/cowling/RasPi_i2c_dummy.py
